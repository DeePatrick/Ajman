﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using Newtonsoft.Json;

namespace APTCWEB.Models
{
    public class Vehicle_APTC
    {
        public string Id { get; set; }

        [Required(ErrorMessage = "Key number is required")]
        public string KeyID { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string DocType { get; set; }

        [Required(ErrorMessage = "engine number is required")]
        public string EngineNum { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string NumSeats { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string TrafficNum { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string FirstRegData { get; set; }

        [Required(ErrorMessage = "year manufacture is required")]
        public string YearManufacture { get; set; }

        [Required(ErrorMessage = "makemodel is required")]
        public string MakeModel { get; set; }

        [Required(ErrorMessage = "colour is required")]
        public string Colour { get; set; }

        [Required(ErrorMessage = "vehicle type is required")]
        public string VehType { get; set; }

        [Required(ErrorMessage = "fuel type is required")]
        public string FuelType { get; set; }

        [Required(ErrorMessage = "trans type is required")]
        public string TransType { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public bool VehValid { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public bool DisabledFriendly { get; set; }

        public VehPlate VehPlate { get; set; }

        public AuditInfo AuditInfo { get; set; }

        public CTResponse CTResponse { get; set; }
    }
    public class VehPlate
    {
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string platename { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string platetype { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string platecode { get; set; }
    }
}
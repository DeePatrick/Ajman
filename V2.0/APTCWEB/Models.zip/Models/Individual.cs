﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace APTCWEB.Models
{
//    {
//  "KeyID": "00002",
//  "DocType": "type",
//  "Email": "text",
//  "Name": {
//    "Lang": {
//      "Name": {}
//    }
//  },
//  "MobNum": {
//    "City": "num",
//    "Area": "num",
//    "Num": "num"
//  },
//  "TelNum": {
//    "City": "num",
//    "Area": "num",
//    "Num": "num"
//  },
//  "DOB": "text",
//  "Nationality": "text",
//  "Religion": "text",
//  "Notes": "text",
//  "Gender": "text",
//  "Language": "text",
//  "MaritalStatus": "text",
//  "Roles": {},
//  "Fines": {},
//  "Documents": {},
//  "Vehicles": {},
//  "AuditInfo": {
//    "Version": "1",
//    "Status": "text",
//    "DataLastChange": "text",
//    "LastChangeBy": "text"
//  }
//}
    public class Individual
    {
        public string KeyID { get; set; }
        public string EmiratiID { get; set; }
        public string DocType { get; set; }
        [Required(ErrorMessage = "email is required")]
        [EmailAddress(ErrorMessage = "please enter valid email address")]
        public string Email { get; set; }
        public string DOB { get; set; }
        public string Nationality { get; set; }
        public string Notes { get; set; }
        public string Gender { get; set; }
        public string Language { get; set; }
        public string MaritalStatus { get; set; }
        public List<Roles> Roles { get; set; }
        public List<Fines> Fines { get; set; }
        public List<Documents> Documents { get; set; }
        public List<Vehicles> Vehicles { get; set; }
        public MobNum MobNum { get; set; }
        public TelNum TelNum { get; set; }
        public AuditInfo AuditInfo { get; set; }
        public Name Name { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string EmailOtp { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string MobileOtp { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string OtpDateTime { get; set; }
    }
    public class MobNum
    {
        [Required(ErrorMessage = "country code is required")]
        public string CountryCode { get; set; }
        [Required(ErrorMessage = "phone is required")]
        public string Num { get; set; }
    }
    public class TelNum
    {
        public string CountryCode { get; set; }
        public string Num { get; set; }
    }
    //public class AuditInfo
    //{
    //    public string Version { get; set; }
    //    public string Status { get; set; }
    //    public string LastChangeDate { get; set; }
    //    public string LastChangeBy { get; set; }
    //}
    public class Name
    {
        public AR AR { get; set; }
        public EN EN { get; set; }
    }
    
    public class AR
    {
        public string FullName { get; set; }
    }
    public class EN
    {
        public string FullName { get; set; }
    }
    public class Roles
    {
        public string Code { get; set; }
        public string Name { get; set; }
    }
    public class Fines
    {
        public string Date { get; set; }
        public string Amount { get; set; }
        public string Remark { get; set; }
    }
    public class Documents
    {
        public string Date { get; set; }
        public string Name { get; set; }
        public string Path { get; set; }
    }
    public class Vehicles
    {
        public string Name { get; set; }
        public string Model { get; set; }
        public string Type { get; set; }
    }
}
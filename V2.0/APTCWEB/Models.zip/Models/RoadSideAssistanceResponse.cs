﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace APTCWEB.Models
{
    public class RoadSideAssistanceResponse
    {
        public string RequestRefID { get; set; }
        public string Message { get; set; }
        public string Telephone { get; set; }
    }
}
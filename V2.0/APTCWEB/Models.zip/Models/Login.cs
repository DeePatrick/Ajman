﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace APTCWEB.Models
{
    public class Login
    {
        public string Id { get; set; }
        [Required(ErrorMessage = "User Id is required")]
        public string UserId { get; set; }
        [Required(ErrorMessage = "Password is required")]
        public string Password { get; set; }
        [Required(ErrorMessage = "User type is required")]
        public string Type { get; set; }
        public string Status { get; set; }
        [Required(ErrorMessage = "Role required")]
        public string Role { get; set; }
        [Required(ErrorMessage = "Per. language is required")]
        public string Pre_language { get; set; }
        public string Created_on { get; set; }
        public string Created_by { get; set; }
        public string Modify_by { get; set; }
        public string Modify_on { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace APTCWEB.Models
{
    public class RoadsideAssistanceModel
    {
        [Required(ErrorMessage = "Passenger ID is required")]
        public string PassengerID { get; set; }

        [Required(ErrorMessage = "Mobile number is required")]
        public string MobileNumber { get; set; }

        [Required(ErrorMessage = "Latitude ID is required")]
        public string Latitude { get; set; }

        [Required(ErrorMessage = "Longitute ID is required")]
        public string Longitude { get; set; }

        [Required(ErrorMessage = "ServiceRequired is required")]
        public string ServiceRequired { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Comments { get; set; }

        public AuditInfo AuditInfo { get; set; }
    }
    public class RoadsideAssistanceModelOutPut
    {
        public string RequestRefID { get; set; }
        public string Message { get; set; }
        public string Telephone { get; set; }
    }
}
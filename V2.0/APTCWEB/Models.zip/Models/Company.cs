﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace APTCWEB.Models
{
    public class Company
    {
        //        {
        //  "KeyID": "00002",
        //  "DocType": "type",
        //  "Email": "text",
        //  "Name": {
        //    "Lang": {
        //      "Name": {}
        //    }
        //  },
        //  "Addr": {
        //    "City": "num",
        //    "Zip": "num",
        //    "Lang": "num",
        //    "Line": {}
        //  },
        //  "TelNum": {
        //    "City": "num",
        //    "Area": "num",
        //    "Num": "num"
        //  },
        //  "Website": "text",
        //  "Company": "text",
        //  "Roles": {},
        //  "Fines": {},
        //  "Documents": {},
        //  "Vehicles": {},
        //  "AuditInfo": {
        //    "Version": "1",
        //    "Status": "text",
        //    "DataLastChange": "text",
        //    "LastChangeBy": "text"
        //  }
        //}
        public string KeyID { get; set; }
        public string DocType { get; set; }
        [Required(ErrorMessage = "email is required")]
        [EmailAddress(ErrorMessage = "please enter valid email address")]
        public string Email { get; set; }
        public string Website { get; set; }
        public List<Roles> Roles { get; set; }
        public List<Fines> Fines { get; set; }
        public List<Documents> Documents { get; set; }
        public List<Vehicles> Vehicles { get; set; }
        public MobNum MobNum { get; set; }
        public TelNum TelNum { get; set; }
        public AuditInfo AuditInfo { get; set; }
        public Address Address { get; set; }
        public Name Name { get; set; }
    }

    public class Address
    {
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string AddressLine1 { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string AddressLine2 { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        [Required(ErrorMessage = "city is required")]
        public string City { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        [Required(ErrorMessage = "zip is required")]
        public string Zip { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        [Required(ErrorMessage = "state is required")]
        public string State { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        [Required(ErrorMessage = "country is required")]
        public string Country { get; set; }
        public Line Line { get; set; }
    }
    public class Line
    {
        [Required(ErrorMessage = "address line1 is required")]
        public string Line1 { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Line2 { get; set; }
    }
}
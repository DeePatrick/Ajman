﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace APTCWEB.Models
{
    public class Journey:CommonModel
    {
        public string BookingId { get; set; }
        public string VehicleID { get; set; }
        public string PassengerID { get; set; }
        public string DriverID { get; set; }
        public string PickupDateTime { get; set; }
        public string PickupAddress { get; set; }
        public string PickupLon { get; set; }
        public string PickupLat { get; set; }
        public string DestinationAddress { get; set; }
        public string DestinationLon { get; set; }
        public string DestinationLat { get; set; }
        public string Waypoints { get; set; }
        public string NumPassengers { get; set; }
        public string TaxiType { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace APTCWEB.Models
{
    public class DriverStatusModel
    {
    
        public string DriverID { get; set; }

        [Required(ErrorMessage = "Driver State is required")]
        public string DriverState { get; set; }

        [Required(ErrorMessage = "Date is required")]
        public string Date { get; set; }

        [Required(ErrorMessage = "Time is required")]
        public string Time { get; set; }

        [Required(ErrorMessage = "Vehicle ID is required")]
        public string VehicleID { get; set; }

    }
}
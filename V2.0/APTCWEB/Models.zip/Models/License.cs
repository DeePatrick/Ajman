﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace APTCWEB.Models
{
    public class License: CommonModel
    {
        public string Id { get; set; }
        public string Action { get; set; }
        [Required(ErrorMessage = "issuedate is required")]
        public string IssueDate { get; set; }
        [Required(ErrorMessage = "expirydate is required")]
        public string ExpiryDate { get; set; }
        [Required(ErrorMessage = "licensenumber is required")]
        public string LicenseNumber { get; set; }
      
    }
}
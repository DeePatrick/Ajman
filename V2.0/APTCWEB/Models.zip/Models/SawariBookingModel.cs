﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using Newtonsoft.Json;

namespace APTCWEB.Models
{
    public class SawariBookingModel
    {
        [Required(ErrorMessage = "Passenger ID is required")]
        public string PassengerID { get; set; }

        [Required(ErrorMessage = "Mobile number is required")]
        public string MobileNumber { get; set; }

        [Required(ErrorMessage = "From Location is required")]
        public string FromLocation { get; set; }

        [Required(ErrorMessage = "To Location is required")]
        public string ToLocation { get; set; }

        [Required(ErrorMessage = "Booking Date & Time Required is required")]
        public string DateTimeRequired { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Comments { get; set; }

        public AuditInfo AuditInfo { get; set; }
    }
}
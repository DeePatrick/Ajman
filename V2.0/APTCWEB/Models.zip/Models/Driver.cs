﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace APTCWEB.Models
{
    public class DriverModel
    {
        public string Id { get; set; }
        [Required(ErrorMessage = "Emirati Id is required")]
        public string EmiratiId { get; set; }
        [Required(ErrorMessage = "first name en is required")]
        public string FirstNameEN { get; set; }
        [Required(ErrorMessage = "last name en is required")]
        public string LastNameEN { get; set; }
        [Required(ErrorMessage = "first name ar is required")]
        public string FirstNameAR { get; set; }
        [Required(ErrorMessage = "last name ar is required")]
        public string LastNameAR { get; set; }
        [Required(ErrorMessage = "mobile number is required")]
        [RegularExpression(@"^(\d{10})$", ErrorMessage = "invalid mobile number")]
        public string MobileNumber { get; set; }
        [Required(ErrorMessage = "emailaddress is required")]
        [EmailAddress(ErrorMessage = "invalid email")]
        public string EmailAddress { get; set; }
        [Required(ErrorMessage = "vehicle type is required")]
        public string VehicleType { get; set; }
        [Required(ErrorMessage = "permit number is required")]
        public string PermitNumber { get; set; }
        [Required(ErrorMessage = "license number is required")]
        public string LicenseNumber { get; set; }
        [Required(ErrorMessage = "pasport number is required")]
        public string PasportNumber { get; set; }
        [Required(ErrorMessage = "issuedate is required")]
        public string LicenseIssueDate { get; set; }
        [Required(ErrorMessage = "expirydate is required")]
        public string LicenseExpiryDate { get; set; }
        public string Photo { get; set; }
        public string Password { get; set; }
        public string DriverValid { get; set; }
        public string Action { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsActive { get; set; }
        public string CreatedDate { get; set; }
        public string ModifiedDate { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        public CarTrackDriverResponse CarTrackDriverResponse { get; set; }
    }
    public class CarTrackDriverResponse
    {
        public string CTStatus { get; set; }
        public string CTDescription { get; set; }
    }
}
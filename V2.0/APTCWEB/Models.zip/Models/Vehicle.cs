﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace APTCWEB.Models
{

   public class Vehicle
    {
        
        public string Action { get; set; }

        public string Id { get; set; }

        public bool VehicleValid { get; set; }

        [Required(ErrorMessage = "Owner name is required")]
        public string OwnerName { get; set; }

        public string Photo { get; set; }

        [Required(ErrorMessage = "VIN number is required")]
        public string Vin { get; set; }

        [Required(ErrorMessage = "engine number is required")]
        public string EngineNumber { get; set; }

        [Required(ErrorMessage = "registration numbetr is required")]
        public string Registration { get; set; }

        [Required(ErrorMessage = "vehicle type is required")]
        public string Vehicletype { get; set; }

        [Required(ErrorMessage = "make is required")]
        public string Make { get; set; }

        [Required(ErrorMessage = "model number is required")]
        public string Model { get; set; }

        [Required(ErrorMessage = "model year is required")]
        public string ModelYear { get; set; }

        [Required(ErrorMessage = "colour is required")]
        public string Colour { get; set; }

        /// <summary>
        /// //////// Add two new field as per new vehicle schema [APTCCRM]
        /// </summary>
        public bool DisabledFriendly { get; set; }
       
        public string PassengerCapacity { get; set; }

        public bool IsDeleted { get; set; }
        public bool IsActive { get; set; }
        public string CreatedDate { get; set; }
        public string ModifiedDate { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }

        public CarTrackVehicleResponse CarTrackVehicleResponse { get; set; }

    }

   public class CarTrackVehicleResponse
    {
        public string CTStatus { get; set; }
        public string CTDescription { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace APTCWEB.Models
{
    public class PassengerMessageModel
    {
        public string Action { get; set; }

        public string PassengerID { get; set; }

        [Required(ErrorMessage = "First Name AR is required")]
        public string FirstNameAR { get; set; }

        [Required(ErrorMessage = "Last Name AR is required")]
        public string LastNameAR { get; set; }

        [Required(ErrorMessage = "First Name EN numbetr is required")]
        public string FirstNameEN { get; set; }

        [Required(ErrorMessage = "Last Name EN is required")]
        public string LastNameEN { get; set; }

        [Required(ErrorMessage = "Mobile Number is required")]
        public string MobileNumber { get; set; }

        [Required(ErrorMessage = "Email Address is required")]
        public string EmailAddress { get; set; }
    }
}